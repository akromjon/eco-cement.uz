<header class="d-flex   justify-content-center py-3 mb-4 border-bottom">
    <a href="/" class="d-flex w-25 align-items-center  mb-md-0 me-md-auto text-dark text-decoration-none">
        <img class="logo" src="{{asset('assets/img/logo/logo1.png')}}" alt="">
    </a>
    <div class="text-block-t w-50 text-center">
        @yield("title")
    </div>
    <div class="w-25  text-end">
        <a href="/logout">
            <img class="w-40" src="{{asset('assets/img/icon/logout.png')}}" alt="">
        </a>
    </div>
</header>
