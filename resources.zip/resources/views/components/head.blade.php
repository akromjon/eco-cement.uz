<!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- Bootstrap CSS -->
<link href="{{asset('assets/css/bootstrap.min.css')}}" rel="stylesheet" crossorigin="anonymous">
<link href="{{asset('assets/css/main.css')}}" rel="stylesheet">
<title>
    @yield('title') | Tinch.uz
</title>
